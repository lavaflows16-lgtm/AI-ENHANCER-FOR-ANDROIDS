package com.example.gameenhancer
import android.content.Context
import android.graphics.SurfaceTexture
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Draws captured frames with sharpen + saturation + contrast. Swap the fragment shader for a neural pass later. */
class EnhanceRenderer(
    private val ctx: Context,
    private val onSurface: (Surface, Int, Int) -> Unit,
) : GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {
    var view: GLSurfaceView? = null
    private var prog = 0; private var tex = 0; private var st: SurfaceTexture? = null
    private var started = false; private var w = 1; private var h = 1
    private val tm = FloatArray(16)
    private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer()
        .apply { put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0) }

    private val vs = "attribute vec4 p; varying vec2 uv; void main(){gl_Position=p; uv=(p.xy+1.0)*0.5;}"
    private val fs = """
        #extension GL_OES_EGL_image_external : require
        precision mediump float;
        uniform samplerExternalOES t; uniform mat4 tm; uniform vec2 px;
        uniform float sharp; uniform float sat; uniform float con;
        varying vec2 uv;
        vec3 s(vec2 o){ return texture2D(t,(tm*vec4(uv+o,0.0,1.0)).xy).rgb; }
        void main(){
            vec3 c=s(vec2(0.0));
            vec3 b=(s(vec2(px.x,0.0))+s(vec2(-px.x,0.0))+s(vec2(0.0,px.y))+s(vec2(0.0,-px.y)))*0.25;
            c+= (c-b)*sharp;
            float l=dot(c,vec3(0.299,0.587,0.114));
            c=mix(vec3(l),c,sat);
            c=(c-0.5)*con+0.5;
            gl_FragColor=vec4(clamp(c,0.0,1.0),1.0);
        }""".trimIndent()

    private fun sh(type: Int, src: String) = GLES20.glCreateShader(type).also { GLES20.glShaderSource(it, src); GLES20.glCompileShader(it) }

    override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) {
        prog = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, sh(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(it, sh(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(it)
        }
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); tex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        st = SurfaceTexture(tex).also { it.setOnFrameAvailableListener(this) }
    }

    override fun onSurfaceChanged(g: GL10?, width: Int, height: Int) {
        w = width; h = height; GLES20.glViewport(0, 0, w, h)
        if (!started) { started = true; st!!.setDefaultBufferSize(w, h); onSurface(Surface(st), w, h) }
    }

    override fun onDrawFrame(g: GL10?) {
        st?.updateTexImage(); st?.getTransformMatrix(tm)
        GLES20.glUseProgram(prog)
        val a = GLES20.glGetAttribLocation(prog, "p")
        GLES20.glEnableVertexAttribArray(a); GLES20.glVertexAttribPointer(a, 2, GLES20.GL_FLOAT, false, 8, quad)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "tm"), 1, false, tm, 0)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(prog, "px"), 1f / w, 1f / h)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "sharp"), Prefs.get(ctx, "sharp", 40) / 50f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "sat"), 0.5f + Prefs.get(ctx, "sat", 55) / 50f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "con"), 0.75f + Prefs.get(ctx, "con", 50) / 200f)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    override fun onFrameAvailable(s: SurfaceTexture?) { view?.requestRender() }
}
