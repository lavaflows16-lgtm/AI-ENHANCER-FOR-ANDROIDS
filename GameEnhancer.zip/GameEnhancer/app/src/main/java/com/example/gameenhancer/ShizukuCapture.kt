package com.example.gameenhancer
/**
 * SCAFFOLD, NOT WORKING YET. Mode 0 needs the Shizuku API (dev.rikka.shizuku) plus a privileged
 * display capture that excludes this app's own overlay layer, so the enhanced output is not re-captured.
 * Plan: bind a Shizuku user service running as shell, capture the display there, feed frames into
 * EnhanceRenderer's SurfaceTexture. This needs on-device testing per Android version.
 */
object ShizukuCapture {
    fun status() = "Shizuku mode is not implemented yet. Use Screen capture mode."
}
