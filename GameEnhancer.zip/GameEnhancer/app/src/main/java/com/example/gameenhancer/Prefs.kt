package com.example.gameenhancer
import android.content.Context
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", 0)
    fun get(c: Context, k: String, d: Int) = sp(c).getInt(k, d)
    fun set(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
}
