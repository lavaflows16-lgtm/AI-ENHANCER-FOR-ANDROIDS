package com.example.gameenhancer
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast

class EnhancerService : Service() {
    private var mp: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var glView: GLSurfaceView? = null
    private var bubble: View? = null
    private val wm by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("enh", "Enhancer", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "enh").setContentTitle("Game Enhancer running")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        when (Prefs.get(this, "mode", 1)) {
            0 -> { // Shizuku mode: see ShizukuCapture.kt (scaffold)
                Toast.makeText(this, ShizukuCapture.status(), Toast.LENGTH_LONG).show(); stopSelf()
            }
            else -> startProjection(intent)
        }
        return START_NOT_STICKY
    }

    private fun startProjection(intent: Intent?) {
        val code = intent?.getIntExtra("code", Activity.RESULT_CANCELED) ?: return stopSelf()
        val data = intent.getParcelableExtra<Intent>("data") ?: return stopSelf()
        mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        mp!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)

        val pct = Prefs.get(this, "size", 40).coerceIn(20, 100)
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            dm.widthPixels * pct / 100, dm.heightPixels * pct / 100,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        val r = EnhanceRenderer(this) { surface, w, h ->
            main.post { vd = mp?.createVirtualDisplay("enh", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null) }
        }
        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2); setRenderer(r); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY; r.view = this
        }
        wm.addView(glView, lp)
        if (Prefs.get(this, "bubble", 1) == 1) addBubble()
    }

    private fun addBubble() {
        val b = TextView(this).apply { text = "AI"; setPadding(30, 30, 30, 30); setBackgroundColor(0xAA000000.toInt()); setTextColor(-1) }
        val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; y = 300 }
        var sy = 0f; var oy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sy = e.rawY; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawY - sy) > 10) moved = true; lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(b, lp) }
                MotionEvent.ACTION_UP -> if (!moved) glView?.let { it.visibility = if (it.visibility == View.VISIBLE) View.INVISIBLE else View.VISIBLE }
            }
            true
        }
        bubble = b; wm.addView(b, lp)
    }

    override fun onDestroy() {
        vd?.release(); mp?.stop()
        glView?.let { wm.removeView(it) }; bubble?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
