package com.example.gameenhancer
import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) startForegroundService(Intent(this, EnhancerService::class.java)
            .putExtra("code", r.resultCode).putExtra("data", r.data))
    }
    private val modes = listOf("Shizuku capture (scaffold)", "Screen capture overlay", "System game tools")

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        col.addView(TextView(this).apply { text = "Game Enhancer"; textSize = 24f })
        val rg = RadioGroup(this)
        modes.forEachIndexed { i, m -> rg.addView(RadioButton(this).apply { text = m; id = i + 100 }) }
        rg.check(Prefs.get(this, "mode", 1) + 100)
        rg.setOnCheckedChangeListener { _, id -> Prefs.set(this, "mode", id - 100) }
        col.addView(rg)
        col.addView(slider("Sharpness", "sharp", 40)); col.addView(slider("Saturation", "sat", 55))
        col.addView(slider("Contrast", "con", 50)); col.addView(slider("Overlay size % (20-100)", "size", 40))
        col.addView(Switch(this).apply {
            text = "Floating AI bubble (tap to toggle)"; isChecked = Prefs.get(this@MainActivity, "bubble", 1) == 1
            setOnCheckedChangeListener { _, c -> Prefs.set(this@MainActivity, "bubble", if (c) 1 else 0) }
        })
        col.addView(Button(this).apply { text = "Start"; setOnClickListener { start() } })
        col.addView(Button(this).apply { text = "Stop"; setOnClickListener { startService(Intent(this@MainActivity, EnhancerService::class.java).setAction("STOP")) } })
        col.addView(TextView(this).apply { text = "Tip: full-size overlay in screen capture mode re-captures itself. Use a smaller size." })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun slider(label: String, key: String, def: Int): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 30, 0, 0) }
        val tv = TextView(this).apply { text = "$label: ${Prefs.get(this@MainActivity, key, def)}" }
        val sb = SeekBar(this).apply {
            max = 100; progress = Prefs.get(this@MainActivity, key, def)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) { Prefs.set(this@MainActivity, key, p); tv.text = "$label: $p" }
                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) {}
            })
        }
        box.addView(tv); box.addView(sb); return box
    }

    private fun start() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        when (Prefs.get(this, "mode", 1)) {
            0 -> startForegroundService(Intent(this, EnhancerService::class.java))
            1 -> projLauncher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
            else -> openGameTools()
        }
    }

    // Package names are best-effort guesses and vary by phone; falls back to a message.
    private fun openGameTools() {
        val pkgs = listOf("com.samsung.android.game.gametools", "com.oplus.games", "com.xiaomi.gamecenter.sdk.service", "com.asus.gamewidget")
        val i = pkgs.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (i != null) startActivity(i) else Toast.makeText(this, "No known game tools app found on this phone", Toast.LENGTH_LONG).show()
    }
}
